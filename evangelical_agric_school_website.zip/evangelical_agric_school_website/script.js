const menuToggle = document.getElementById('menuToggle');
const primaryNav = document.getElementById('primaryNav');

menuToggle?.addEventListener('click', () => {
  const isOpen = primaryNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.textContent = isOpen ? 'Close ✕' : 'Menu ☰';
});

primaryNav?.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    primaryNav.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    if (menuToggle) menuToggle.textContent = 'Menu ☰';
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

const portalInfoBtn = document.getElementById('portalInfoBtn');
const portalMessage = document.getElementById('portalMessage');
portalInfoBtn?.addEventListener('click', () => {
  portalMessage.hidden = !portalMessage.hidden;
  portalInfoBtn.setAttribute('aria-expanded', String(!portalMessage.hidden));
});

const contactForm = document.getElementById('contactForm');
const formMessage = document.getElementById('formMessage');
contactForm?.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!contactForm.reportValidity()) return;
  formMessage.hidden = false;
  formMessage.textContent = 'Your form passed local validation, but this preview does not send or store messages. Please contact the school through its verified official contact details.';
  contactForm.reset();
});
