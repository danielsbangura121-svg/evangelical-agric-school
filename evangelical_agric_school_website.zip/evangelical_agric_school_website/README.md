# Evangelical Agric Senior Secondary School Website

A responsive static website starter for EVANGELICAL AGRIC SENIOR SECONDARY SCHOOL, BAT KANU.

## Files
- `index.html` — page structure and school content
- `styles.css` — responsive green, white, and gold styling
- `script.js` — mobile navigation and demo form interactions

## Preview on your computer
1. Extract the ZIP file.
2. Open `index.html` in a browser.
3. For a local development server, open the folder in Visual Studio Code and use a local server extension, or run `python -m http.server 8000` from the folder and visit `http://localhost:8000`.

## Publish free with GitHub Pages
1. Sign in at https://github.com/ and create a new public repository, e.g. `evangelical-agric-school`.
2. Upload `index.html`, `styles.css`, `script.js`, and this README (the three website files must be in the repository root).
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish and use the URL shown in Settings → Pages.

## Important limitations
This is a static public website starter. The contact form only performs browser-side validation and does not send or store submissions. The student portal is an informational placeholder, not a real login. Admissions are not stored. There is no database, administrator dashboard, or private results system yet.

Before handling real student information, admissions, or grades, connect a secure backend with authentication, server-side authorization, database persistence, and protected file storage. Do not publish real student records in this static site.

## Before official launch
Replace placeholder content with school-approved information, including official history, mission and vision, phone, email, exact location, school fees, subject list, admission requirements, staff names, and approved photographs/logo.
